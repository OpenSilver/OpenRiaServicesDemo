﻿using System.Windows.Controls;
using System.Windows.Navigation;

namespace $ext_safeprojectname$.Views
{
    public partial class About : Page
    {
        public About()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }
    }
}